class Guess:

    def __init__(self, word):
        self.secretWord = word
        self.guessedChars = {'e', 'n'}
        self.currentStatus = "_" * len(word)
        self.guess('')

    def guess(self, character):
        self.guessedChars |= {character}
        if character in self.secretWord:
            tmp = ''
            for i in self.secretWord:
                if i in self.guessedChars:
                    tmp += i
                else:
                    tmp += '_'
            self.currentStatus = tmp
            return True
        else:
            return False

    def finished(self):
        if self.currentStatus == self.secretWord:
            return True

    def displayCurrent(self):
        guessWord= ''
        for i in self.currentStatus:
            guessWord += (i + ' ')
        return guessWord

    def displayGuessed(self):
        guessed = ''
        for i in sorted(list(self.guessedChars)):
            guessed += (i + ' ')
        return guessed
