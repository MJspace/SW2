import unittest

from hangman import Hangman

class TestHangman(unittest.TestCase):

    def setUp(self):
        self.g1 = Hangman()

    def tearDown(self):
        pass

    def testDecreaseLife(self):
        self.assertEqual(self.g1.remainingLives, 6)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 5)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 4)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 3)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 2)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 1)
        self.g1.decreaseLife()
        self.assertEqual(self.g1.remainingLives, 0)

    def testCurrentShape(self):
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |
  |
  |
  |
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |
  |
  |
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |    |
  |    |
  |
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |   /|
  |    |
  |
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |   /|\\
  |    |
  |
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |   /|\\
  |    |
  |   /
 _|_
|   |______
|          |
|__________|\
'''
        )
        self.g1.decreaseLife()
        self.assertEqual(self.g1.currentShape(),
        '''\
   ____
  |    |
  |    o
  |   /|\\
  |    |
  |   / \\
 _|_
|   |______
|          |
|__________|\
'''
        )

if __name__ == '__main__':
    unittest.main()