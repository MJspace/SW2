import unittest

from word import Word

class TestWord(unittest.TestCase):

    def setUp(self):
        self.g1 = Word('words.txt')

    def tearDown(self):
        pass

    def testRandFromDB(self):
        filename = 'words.txt'
        word_list = []
        f = open(filename, 'r')
        line_cnt = f.readlines()
        f.close()

        cnt = 0
        for line in line_cnt:
            word = line.rstrip()
            word_list.append(word)
            cnt += 1

        self.assertEqual(self.g1.count, cnt)
        self.assertEqual(len(self.g1.words), len(word_list))
        self.assertIn(self.g1.randFromDB(), word_list)

    if __name__ == '__main__':
        unittest.main()